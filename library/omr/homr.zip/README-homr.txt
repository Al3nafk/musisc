homr by Christian Liebhardt and contributors, AGPL-3.0, https://github.com/liebharc/homr
Patched by tools/omr-build.js in Musisc: model calls are awaited so they can run on onnxruntime-web.
